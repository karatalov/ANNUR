const WRITER = {
  name: "Чыңгыз Айтматов",
  dates: "1928 — 2008"
};
