const HOME_FEATURED = [
  { title: "Кыргыз маданияты", toPage: "person" }
];
