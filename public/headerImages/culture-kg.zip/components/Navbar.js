function Navbar({ setPage }) {
  return (
    <div>
      <button onClick={()=>setPage("home")}>Home</button>
      <button onClick={()=>setPage("person")}>Person</button>
      <button onClick={()=>setPage("works")}>Works</button>
    </div>
  );
}
