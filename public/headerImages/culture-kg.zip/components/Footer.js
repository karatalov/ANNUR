function Footer() {
  return <footer>© 2026 Culture KG</footer>;
}
