function PersonPage() {
  return (
    <div>
      <h1>{WRITER.name}</h1>
      <p>{WRITER.dates}</p>
    </div>
  );
}
