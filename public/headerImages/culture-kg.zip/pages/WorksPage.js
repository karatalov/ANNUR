function WorksPage() {
  return (
    <div>
      <h1>Works</h1>
      {GENRES.map(g=>(
        <div key={g.id}>
          <h2>{g.title}</h2>
        </div>
      ))}
    </div>
  );
}
