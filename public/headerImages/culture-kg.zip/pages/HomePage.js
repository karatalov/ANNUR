function HomePage({ setPage }) {
  return (
    <div>
      <h1>Home</h1>
      {HOME_FEATURED.map((f, i)=>(
        <div key={i} onClick={()=>setPage(f.toPage)}>
          {f.title}
        </div>
      ))}
    </div>
  );
}
